import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  public apiUrl = 'https://my-json-server.typicode.com/banshilaldangi/ecommerce/products/';
  public featureUrl = 'https://my-json-server.typicode.com/banshilaldangi/ecommerce/features/';
  public brandsUrl = 'https://my-json-server.typicode.com/banshilaldangi/ecommerce/brands/';
  public categoryUrl = 'https://my-json-server.typicode.com/banshilaldangi/ecommerce/categories/';
  headers = new HttpHeaders().set('Content-Type', 'application/json');

  constructor(private http: HttpClient) { }
  // showTasks() {
  //   return this.http.get(`${this.apiUrl}`);
  // }
  showTasks(): Observable<any> {
    console.log('test');
    return this.http.get(this.apiUrl);
}
showProductInfo(id): Observable<any> {
  return this.http.get(this.apiUrl + id);
}
showFeatures(): Observable<any> {
  return this.http.get(this.featureUrl);
}
showFeaturesInfo(id): Observable<any> {
  return this.http.get(this.featureUrl + id);
}
showBrands(): Observable<any> {
  return this.http.get(this.brandsUrl);
}
showBrandsDetais(id): Observable<any> {
  return this.http.get(this.brandsUrl + id);
}
showBrandsInfo(id): Observable<any> {
  return this.http.get(this.apiUrl + '?brand_id=' + id);
}
showCategory(): Observable<any> {
  return this.http.get(this.categoryUrl);
}
showCategoryInfo(id): Observable<any> {
  return this.http.get(this.categoryUrl + id);
}
showProductcategoryInfo(id): Observable<any> {
  return this.http.get(this.apiUrl + '?category_id=' + id);
}
}
