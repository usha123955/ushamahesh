import { Gg } from './gg';

describe('Gg', () => {
  it('should create an instance', () => {
    expect(new Gg()).toBeTruthy();
  });
});
