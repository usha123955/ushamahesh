import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';
import {MatButtonModule} from '@angular/material/button';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatCardModule} from '@angular/material/card';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor(private productService: ProductService) { }
  productArray: any = [];
  category: any;
  categoryArray: any = [];
  brandsArray: any = [];
  tempArray: any = [];
  categoryid: any;

  ngOnInit() {
    this.getProduct();
    this.getCategory();
    this.getBrands();
  }
  // getProduct(){
  //   this.productArray = this.productService.showTasks();
  // }
  getProduct() {
    this.productService.showTasks()
      .subscribe(
        results => {
          this.productArray = results;
        },
        error => {
          // console.log(<any>error);
        });
  }
  getCategory() {
    this.productService.showCategory()
      .subscribe(
        results => {
          this.categoryArray = results;
          console.log(this.categoryArray);
        },
        error => {
          // console.log(<any>error);
        });
  }
  getBrands() {
    this.productService.showBrands()
      .subscribe(
        results => {
          this.brandsArray = results;
        },
        error => {
          // console.log(<any>error);
        });
  }
  activateClass(category) {
    this.category = category;
    this.category.actived = true;

    this.categoryArray.map(cat => {
      if (cat.name !== this.category.name) {
        cat.actived = false;
      }
    });

  }
  onItemChange(value) {
    this.productService.showProductcategoryInfo(value).subscribe(
      results => {
        this.productArray = results;
      },
      error => {
        // console.log(<any>error);
      }
    );
  }
  onItemChangebrand(val) {
    this.productService.showBrandsInfo(val).subscribe(
      results => {
        this.productArray = results;
      },
      error => {
        // console.log(<any>error);
      }
    );
  }

}
