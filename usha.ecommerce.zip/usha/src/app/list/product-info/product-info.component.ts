import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-product-info',
  templateUrl: './product-info.component.html',
  styleUrls: ['./product-info.component.css']
})
export class ProductInfoComponent implements OnInit {
  id: string;
  productArray: any ;
  productInfo: any = [];
  categoryInfo: any = [];
  CatId: any;
  brndId: any;
  brandInfo: any = [];

  constructor(private route: ActivatedRoute, private productService: ProductService) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.id = params.id;
      this.getProductInfo(this.id);
      this.getCategoryInfo(this.id);
  });
  }
  getProductInfo(id) {
    this.productService.showProductInfo(id)
        .subscribe(
            results => {
                this.productInfo = results;
                this.CatId = this.productInfo.category_id;
                this.brndId = this.productInfo.brand_id;
                this.BrandInfo(this.brndId);
            },
            error => {
                console.log(error);
            });
}
getCategoryInfo(id) {
  this.productService.showCategoryInfo(id)
      .subscribe(
          results => {
              this.categoryInfo = results;

          },
          error => {
              console.log(error);
          });
}
BrandInfo(id) {
  this.productService.showBrandsDetais(id)
  .subscribe(
    result => {
      this.brandInfo = result;
    }
  );
}

}
